#ifndef ALGO_H
#define ALGO_H

long fibonacci(const int n);



int reverse(const int n);



int prime_factor(const int n);



int prime_sum(const int n);

#endif
