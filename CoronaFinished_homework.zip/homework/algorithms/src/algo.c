#include "algo.h"
//#include<stdio.h>

//Pray for the best

//Skip, no idea what the buzz a fibonanni sequence even is. 

//I think an array or somehting and then pixk oput the 6th option.
//But I think that biz isn't the point of the this task soo

//Now I'm confused, am I sup[posed to make it so that it can either 
//A. Turn the example fib sequence to choose the 6th option
//B. Or make a user input for any numbers n choose the 6th
//C. Make some code that makes a fib? Then choose 6th?

//Idk all 3 is balooga balls :(
long fibonacci(const int n)
{

//Okay array is the way to go, cassue ithink i get an idea how to do it
int fib[25], f, pnum;
printf("How big you want the fibonacci series:");
//Only go up to 25, i don't want to make an infiitne one or somehting to big
scanf("%d",&number);
fib[0] = 0;
fib[1] = 1;
for (f = 2; f < pnum; f++)
{
    fib[f] = fib[f - 1] + fib[f - 2];
}
printf("The Fib Series n the sixth number of it: \n");
for (i = 0; f < pnum; f++)
{
    printf("%d", fib[f]);
    printf("%d", fib[5])

}

    return 0;
}




//ok

int reverse(const int n)
{

//Ok so ima store some variables, the integer numbers
//I'm assuming a loop with some prgoram biz can work. Shiould be the easierst out of the 4 stuff. 
//Then just simple print at the end. Integer print

 int rev = 0;
while (numb > 0) {
    rev = rev * 10 + rev % 10;
    numb = numb / 10;
}
return rev;

{
    int numb = 123;
    printf("Reverse of %d", rev(numb))
}
//fuk loop idea no go
//
    return 0;
}



int prime_factor(const int n)
{
//Make brain hurt Ima come back to this one

//After doing the prime sum and gettign som ehelp i thought I could just reuse some stuff it, but doing so messes with the logic
//I think i did it reverese so thats all bonked. Probalby somehting simple, so take break come back to it
//I'll use a different variables ints things to not confuse with p j
int t = 12;
int f =2;

while (f <= t) {
    if (t % f == 0) {
        t /= f;

    } else {
        f++
    }

}

//Hopin thats tghe right way to write %d, tis mad confusing
printf("Largest prime factor is %d./t",f);

    return 0;
}




//Find the sum of all prime nuimbers below 1000
int prime_sum(const int n)
{

//One giy recommended swapping the beginning and ebd values?
//A couple other guysd use a bool method
//Add a didvision type of function? Somehtign that checks if a number is divisible by any pther number beseides 1 and itself, it isn't prime, so it isn't printed
//Issues would be how to add them all up, so logic is importnat. Ask for help.
 
//p for loking for prime junk and j after finding the prime junk to add together

 int p, j, psum = 0;


//I think i can just use 'p' and 'j' for prime number "logic" (right?)
 for (p = 2; p < 1000; p++){
    int isa_prime = 1;

//Now thunkin about it, maybe the reverse idea is simmilar to the Reverse and Integer build. Gave up on that method tho so idk.

    for (j = 2; j < p; j++) {
        if (p % j == 0) {
            isa_prime = 0;
            break;
        }
    }

//An integer for the sum(I think bI gotta use "n") 

if (isa_prime) {
    psum += p;
}

 }

//An integer for the sum(I think bI gotta use "n") 
//Or I guess it does it itslef 
  printf("Prime numbers sum is %d.n");

  //Don't change this thing
    return 0;
}


//git add .
//git commit -m "done doing homework"
//git push orgin master